package com.example.debbie.quizapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SharedPreferences sharedpreferences;
    public static final String mypreference = "mypref";
    int NoofCorrectAnswers;


    public RadioGroup QuestionOne;
    public RadioGroup QuestionTwo;
    public RadioGroup QuestionThree;
    public TextView ShowResult;


    private RadioButton Selected;

    public Button Submit;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NoofCorrectAnswers = 0;
        Submit = findViewById(R.id.submit);
        //Shared Preferennce Initialize
        sharedpreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        ShowResult = findViewById(R.id.ShowResult);




        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//QuestionOne
                QuestionOne = findViewById(R.id.capital);
                int ChosenOption = QuestionOne.getCheckedRadioButtonId();
                Selected= findViewById(ChosenOption);

                if((Selected.getText().toString()).equals("Abuja")) {
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("QuestionOne","Correct");

                    NoofCorrectAnswers++;
                    editor.commit();

                }else if((Selected.getText().toString()).equals("Logos")){
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("QuestionOne","Wrong");
                    NoofCorrectAnswers =  NoofCorrectAnswers;
                    editor.commit();
                }
                //Question Two
                QuestionTwo = findViewById(R.id.ALC);
                int secondChosenOption = QuestionTwo.getCheckedRadioButtonId();
                Selected= findViewById(secondChosenOption);

                if((Selected.getText().toString()).equals("Andela Learning Community")) {
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("QuestionTwo","Correct");

                    NoofCorrectAnswers++;
                    editor.commit();

                }else if((Selected.getText().toString()).equals("Abuja Learning Community")) {
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("QuestionTwo","Wrong");

                    NoofCorrectAnswers=  NoofCorrectAnswers;
                    editor.commit();

                }

                QuestionThree = findViewById(R.id.capital1);
                int thirdChosenOption =  QuestionThree.getCheckedRadioButtonId();
                Selected= findViewById(thirdChosenOption);

                if((Selected.getText().toString()).equals("Yes")) {
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("QuestionThree","Correct");

                    NoofCorrectAnswers++;
                    editor.commit();

                }else if((Selected.getText().toString()).equals("No")){
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("QuestionThree","Wrong");

                    NoofCorrectAnswers=  NoofCorrectAnswers;
                    editor.commit();
                }

                String Tell = "You had";
                String TellCOmplete = " Question Correct";
                String Noone ="QuestionOne Was";
                String Notwo = "QuestionTwo Was";
                ShowResult.setText(Tell+NoofCorrectAnswers+TellCOmplete);


            }
        });



    }



}

